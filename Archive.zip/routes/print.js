var pdfkit = require('pdfkit');
var options = {};
options.size = 'FOLIO';

var print = module.exports = function(content,callback){
	var doc = new pdfkit(options);
	doc.fontSize(32);
	doc.font('Times-Roman');
	doc.image('./routes/template2.png', 10, 10,{width: 590, height: 450});
	doc.fontSize(32);
//Box A
	doc.text(content[0].box[0],128,85);
	doc.text(content[0].box[1],173,85);
	
	doc.text(content[0].box[2],128,130);
	doc.text(content[0].box[3],173,130);
	
	doc.text(content[0].box[4],128,175);
	doc.text(content[0].box[5],173,175);
	
	doc.fontSize(12);
	doc.text(content[0].series,170,222);
//Box B
	doc.fontSize(32);
	doc.text(content[1].box[0],235,85);
	doc.text(content[1].box[1],280,85);
	doc.text(content[1].box[2],327,85);
	
	doc.text(content[1].box[3],235,130);
	doc.text(content[1].box[4],280,130);
	doc.text(content[1].box[5],327,130);
	
	doc.text(content[1].box[6],235,175);
	doc.text(content[1].box[7],280,175);
	doc.text(content[1].box[8],327,175);
	doc.fontSize(12);
	doc.text(content[1].series,300,222);
//Box C
	doc.fontSize(32);
	doc.text(content[2].box[0],386,85);
	doc.text(content[2].box[1],432,85);
	doc.text(content[2].box[2],477,85);
	doc.text(content[2].box[3],524,85);

	doc.text(content[2].box[4],386,130);
	doc.text(content[2].box[5],432,130);
	doc.text(content[2].box[6],477,130);
	doc.text(content[2].box[7],524,130);
	
	doc.text(content[2].box[8],386,175);
	doc.text(content[2].box[9],432,175);
	doc.text(content[2].box[10],477,175);
	doc.text(content[2].box[11],524,175);

	doc.fontSize(12);
	doc.text(content[2].series,470,222);
//Box D
	doc.fontSize(32);

	doc.text(content[3].box[0],53,280);
	doc.text(content[3].box[1],100,280);
	doc.text(content[3].box[2],145,280);
	doc.text(content[3].box[3],191,280);
	doc.text(content[3].box[4],237,280);

	doc.text(content[3].box[5],53,325);
	doc.text(content[3].box[6],100,325);
	doc.text(content[3].box[7],145,325);
	doc.text(content[3].box[8],191,325);
	doc.text(content[3].box[9],237,325);

	doc.text(content[3].box[10],53,370);
	doc.text(content[3].box[11],100,370);
	doc.text(content[3].box[12],145,370);
	doc.text(content[3].box[13],191,370);
	doc.text(content[3].box[14],237,370);

	doc.fontSize(12);
	doc.text(content[3].series,160,417);
//Box E
	doc.fontSize(32);

	doc.text(content[4].box[0],293,280);
	doc.text(content[4].box[1],339,280);
	doc.text(content[4].box[2],386,280);
	doc.text(content[4].box[3],432,280);
	doc.text(content[4].box[4],478,280);
	doc.text(content[4].box[5],523,280);
	
	doc.text(content[4].box[6],293,325);
	doc.text(content[4].box[7],339,325);
	doc.text(content[4].box[8],386,325);
	doc.text(content[4].box[9],432,325);
	doc.text(content[4].box[10],478,325);
	doc.text(content[4].box[11],523,325);
	
	doc.text(content[4].box[12],293,370);
	doc.text(content[4].box[13],339,370);
	doc.text(content[4].box[14],386,370);
	doc.text(content[4].box[15],432,370);
	doc.text(content[4].box[16],478,370);
	doc.text(content[4].box[17],523,370);

	doc.fontSize(12);
	doc.text(content[4].series,460,417);
//Box F
	doc.fontSize(32);
	
	doc.lineWidth(1);
	doc.lineCap('butt')
		.moveTo(607, 468)
		.lineTo(5, 468)
		.dash(5, {space: 10})
		.fillAndStroke("black");
	doc.image('./routes/template2.png', 10, 478,{width: 590, height: 450});
	
	
	//Box A
	doc.text(content[5].box[0],128,85+467);
	doc.text(content[5].box[1],173,85+467);
	
	doc.text(content[5].box[2],128,130+467);
	doc.text(content[5].box[3],173,130+467);
	
	doc.text(content[5].box[4],128,175+467);
	doc.text(content[5].box[5],173,175+467);
	
	doc.fontSize(12);
	doc.text(content[5].series,170,222+467);
//Box B
	doc.fontSize(32);
//Box B
	doc.text(content[6].box[0],235,85+467);
	doc.text(content[6].box[1],280,85+467);
	doc.text(content[6].box[2],327,85+467);
	
	doc.text(content[6].box[3],235,130+467);
	doc.text(content[6].box[4],280,130+467);
	doc.text(content[6].box[5],327,130+467);
	
	doc.text(content[6].box[6],235,175+467);
	doc.text(content[6].box[7],280,175+467);
	doc.text(content[6].box[8],327,175+467);
	doc.fontSize(12);
	doc.text(content[6].series,300,222+467);
//Box C
	doc.fontSize(32);
	doc.text(content[7].box[0],386,85+467);
	doc.text(content[7].box[1],432,85+467);
	doc.text(content[7].box[2],477,85+467);
	doc.text(content[7].box[3],524,85+467);

	doc.text(content[7].box[4],386,130+467);
	doc.text(content[7].box[5],432,130+467);
	doc.text(content[7].box[6],477,130+467);
	doc.text(content[7].box[7],524,130+467);
	
	doc.text(content[7].box[8],386,175+467);
	doc.text(content[7].box[9],432,175+467);
	doc.text(content[7].box[10],477,175+467);
	doc.text(content[7].box[11],524,175+467);

	doc.fontSize(12);
	doc.text(content[7].series,470,222+467);
//Box D
	doc.fontSize(32);

	doc.text(content[8].box[0],53,280+467);
	doc.text(content[8].box[1],100,280+467);
	doc.text(content[8].box[2],145,280+467);
	doc.text(content[8].box[3],191,280+467);
	doc.text(content[8].box[4],237,280+467);

	doc.text(content[8].box[5],53,325+467);
	doc.text(content[8].box[6],100,325+467);
	doc.text(content[8].box[7],145,325+467);
	doc.text(content[8].box[8],191,325+467);
	doc.text(content[8].box[9],237,325+467);

	doc.text(content[8].box[10],53,370+467);
	doc.text(content[8].box[11],100,370+467);
	doc.text(content[8].box[12],145,370+467);
	doc.text(content[8].box[13],191,370+467);
	doc.text(content[8].box[14],237,370+467);

	doc.fontSize(12);
	doc.text(content[8].series,160,417+467);
//Box E
	doc.fontSize(32);

	doc.text(content[9].box[0],293,280+467);
	doc.text(content[9].box[1],339,280+467);
	doc.text(content[9].box[2],386,280+467);
	doc.text(content[9].box[3],432,280+467);
	doc.text(content[9].box[4],478,280+467);
	doc.text(content[9].box[5],523,280+467);
	
	doc.text(content[9].box[6],293,325+467);
	doc.text(content[9].box[7],339,325+467);
	doc.text(content[9].box[8],386,325+467);
	doc.text(content[9].box[9],432,325+467);
	doc.text(content[9].box[10],478,325+467);
	doc.text(content[9].box[11],523,325+467);
	
	doc.text(content[9].box[12],293,370+467);
	doc.text(content[9].box[13],339,370+467);
	doc.text(content[9].box[14],386,370+467);
	doc.text(content[9].box[15],432,370+467);
	doc.text(content[9].box[16],478,370+467);
	doc.text(content[9].box[17],523,370+467);
	doc.fontSize(12);
	doc.text(content[9].series,460,417+467);
//Box F
	doc.fontSize(32);
	
	doc.lineWidth(1);
	doc.lineCap('butt')
		.moveTo(607, 468)
		.lineTo(5, 468)
		.dash(5, {space: 10})
		.fillAndStroke("black");
	doc.fontSize(12);
	/*
	doc.rotate(270,{origin:[100,80]}).text(content[9].prodid,75,80);
	doc.rotate(0,{origin:[100,80+567]}).text(content[9].prodid,75,80+467);
	*/
	doc.write("v1"+content[9].prodid+" "+content[0].series+"-"+content[9].series+".pdf",function(){
		callback(null,content[9].prodid+" "+content[0].series+"-"+content[9].series+".pdf");
	});
};